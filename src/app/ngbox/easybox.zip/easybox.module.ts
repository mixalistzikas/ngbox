import { NgModule }           from '@angular/core';
import { EasyBoxComponent }   from './easybox.component';
import { EasyBoxDirective }   from './easybox.directive';
import { SharedModule }       from '../shared/shared.module';


@NgModule({
  imports: [ SharedModule ],
  exports: [ EasyBoxComponent, EasyBoxDirective ],
  providers: [ ],
  declarations: [ EasyBoxComponent, EasyBoxDirective ],
})
export class EasyBoxModule {}

