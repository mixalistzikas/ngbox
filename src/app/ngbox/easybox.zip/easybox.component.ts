import { Component, Input, Output, EventEmitter, ViewChild, ElementRef, HostListener, DoCheck } from '@angular/core';
import { EasyBoxService } from './easybox.service';


@Component({
    selector: 'my-easybox',
    template: `
        <div id="easyBoxLoading" *ngIf="easyBox.loading"><img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNv
ZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+PHN2ZyB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxucz0iaHR0cD
ovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjAiIHdpZHRo
PSIxNjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMTI4IDE2IiB4bWw6c3BhY2U9InByZXNlcnZlIj48c2NyaXB0IHR5cGU9InRleHQvZW
NtYXNjcmlwdCIgeGxpbms6aHJlZj0iLy9wcmVsb2FkZXJzLm5ldC9qc2NyaXB0cy9zbWlsLnVzZXIuanMiLz48cGF0aCBmaWxsPSIjZmZmZmZmIiBm
aWxsLW9wYWNpdHk9IjAuNDE5NjA3ODQzMTM3MjUiIGQ9Ik02LjQsNC44QTMuMiwzLjIsMCwxLDEsMy4yLDgsMy4yLDMuMiwwLDAsMSw2LjQsNC44Wm
0xMi44LDBBMy4yLDMuMiwwLDEsMSwxNiw4LDMuMiwzLjIsMCwwLDEsMTkuMiw0LjhaTTMyLDQuOEEzLjIsMy4yLDAsMSwxLDI4LjgsOCwzLjIsMy4y
LDAsMCwxLDMyLDQuOFptMTIuOCwwQTMuMiwzLjIsMCwxLDEsNDEuNiw4LDMuMiwzLjIsMCwwLDEsNDQuOCw0LjhabTEyLjgsMEEzLjIsMy4yLDAsMS
wxLDU0LjQsOCwzLjIsMy4yLDAsMCwxLDU3LjYsNC44Wm0xMi44LDBBMy4yLDMuMiwwLDEsMSw2Ny4yLDgsMy4yLDMuMiwwLDAsMSw3MC40LDQuOFpt
MTIuOCwwQTMuMiwzLjIsMCwxLDEsODAsOCwzLjIsMy4yLDAsMCwxLDgzLjIsNC44Wk05Niw0LjhBMy4yLDMuMiwwLDEsMSw5Mi44LDgsMy4yLDMuMi
wwLDAsMSw5Niw0LjhabTEyLjgsMEEzLjIsMy4yLDAsMSwxLDEwNS42LDgsMy4yLDMuMiwwLDAsMSwxMDguOCw0LjhabTEyLjgsMEEzLjIsMy4yLDAs
MSwxLDExOC40LDgsMy4yLDMuMiwwLDAsMSwxMjEuNiw0LjhaIi8+PGc+PHBhdGggZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIxIiBkPSJNLT
QyLjcsMy44NEE0LjE2LDQuMTYsMCwwLDEtMzguNTQsOGE0LjE2LDQuMTYsMCwwLDEtNC4xNiw0LjE2QTQuMTYsNC4xNiwwLDAsMS00Ni44Niw4LDQu
MTYsNC4xNiwwLDAsMS00Mi43LDMuODRabTEyLjgtLjY0QTQuOCw0LjgsMCwwLDEtMjUuMSw4YTQuOCw0LjgsMCwwLDEtNC44LDQuOEE0LjgsNC44LD
AsMCwxLTM0LjcsOCw0LjgsNC44LDAsMCwxLTI5LjksMy4yWm0xMi44LS42NEE1LjQ0LDUuNDQsMCwwLDEtMTEuNjYsOGE1LjQ0LDUuNDQsMCwwLDEt
NS40NCw1LjQ0QTUuNDQsNS40NCwwLDAsMS0yMi41NCw4LDUuNDQsNS40NCwwLDAsMS0xNy4xLDIuNTZaIi8+PGFuaW1hdGVUcmFuc2Zvcm0gYXR0cm
lidXRlTmFtZT0idHJhbnNmb3JtIiB0eXBlPSJ0cmFuc2xhdGUiIHZhbHVlcz0iMjMgMDszNiAwOzQ5IDA7NjIgMDs3NC41IDA7ODcuNSAwOzEwMCAw
OzExMyAwOzEyNS41IDA7MTM4LjUgMDsxNTEuNSAwOzE2NC41IDA7MTc4IDAiIGNhbGNNb2RlPSJkaXNjcmV0ZSIgZHVyPSI3ODBtcyIgcmVwZWF0Q2
91bnQ9ImluZGVmaW5pdGUiLz48L2c+PC9zdmc+Cg=="/></div>
        <div id="easyBoxWrapper" (click)="closeOutside($event)" *ngIf="easyBox.open" [ngStyle]="{'padding-top': offsetHeight+'px'}">
            <div id="easyBoxContent">
                <img *ngIf="easyBox.current.type == 1"
                     (load)="isLoaded()" 
                     #easyBoxContent 
                     [src]="easyBox.current.url"
                     [hidden]="easyBox.loading" 
                     (click)="nextEasyBox()"
                     alt="">
                <iframe *ngIf="easyBox.current.type == 2" 
                        #easyBoxContent
                        [src]="easyBox.current.url"
                        width="{{easyBox.current.width}}"
                        height="{{easyBox.current.height}}"
                        frameborder="0"
                        allowfullscreen>
                </iframe>
                <iframe *ngIf="easyBox.current.type == 3" 
                        [src]="easyBox.current.url"
                        #easyBoxContent
                        width="{{easyBox.current.width}}"
                        height="{{easyBox.current.height}}"
                        frameborder="0" 
                        webkitallowfullscreen 
                        mozallowfullscreen 
                        allowfullscreen>
                </iframe>
                <iframe *ngIf="easyBox.current.type == 4" 
                        #easyBoxContent
                        [src]="easyBox.current.url"
                        frameborder="0"
                        width="{{easyBox.current.width}}"
                        height="{{easyBox.current.height}}"
                        allowfullscreen>
                </iframe>
            </div>
            <div #easyBoxButtons id="buttons" [hidden]="easyBox.loading">
                <p>
                    <span class="title" *ngIf="easyBox.current.title">{{easyBox.current.title}}<br/></span>
                    <span class="pages" *ngIf="getHasGroup()">{{getCurrentIndex()}} of {{getCount()}}</span>
                </p>
                <img (click)="closeEasyBox()" id="closeButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAbCAMA
AAC6CgRnAAAAPFBMVEX///8AAAD9/f2CgoKAgIAAAAAAAAAAAABLS0sAAAAAAACqqqqqqqq6urpKSkpISEgAAAC7u7u5ubn////zbsMcAAAAE3RSTlMASv6rqwAWS5
YMC7/AyZWVFcrJCYaKfAAAAHhJREFUeF590kkOgCAQRFEaFVGc+/53FYmbz6JqBbyQMFSYuoQuV+iTflnstI7ssLXRvMWRaEMs84e2uVckuZe6knL0hiSPObXhj6Ch
zoEkIolIIpKIO4joICAIeDd7QGIfCCjOKe9HEk8mnxpIAup/F31RPZP9fAG3IAyBSJe0igAAAABJRU5ErkJggg==" alt="">
            </div>


            <img *ngIf="getHasGroup()" class="left" (click)="previousEasyBox()" src="data:image/
png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAJtklEQVR4Xu2dbWwcxRnHn93EvigEQiBAGj
uVSKvEiBYaC/OljmPfXpMYhSCCwvunSlWlIEAkSAhR1LRUgMBJeFEk1C9VKS8SkAgnQMDe2zvFgL/gc5BomwgSUEhAVZr4iF2fW9s71e7d2efb3dvd29n1zM5zn6Lc
7OzM8/89/2dm7m4tAb6EjoAk9Oxx8oAACA4BAoAACB4BwaePDoAACB4BwaePDoAACB4BwaePDoAACB4BwaePDoAACB4BwaePDoAACB4BwaePDoAACB4BwaePDlAHAN
3d3YlCofAjWZYnOzo6vt+9e7deRzdMXIIA+JBBUZQuAHgMCEkCQINxqQQwQgAOSLL8lKqqp310x0RTBMCbDJKiKH8AQp6s0XxUkuVtqqqq3rpkoxUC4K6DlEomnyFG
5gOAvjABp3+2DUZWroMFUxOw4st+uPrrgXIvEwTgNk3T+ty7ZaMFAlBbhzniTy5aCsPdz8HolT81vb/8av7HIVj7yYtcQoAAOANgET93Sw+MXbF69oqK6DX98z1o+X
gfdxAgAPYAWMXvLolfHTHOIUAArAA4i19uWwuC4+9Dy8BebpwAAZgLgFX8zT0wdmWF7ccMAgSgoqJXrvaNBV/OEL9c8+0iVcMJVp74AK47uod5J0AAihLZZ37lgq90
6mOpGD4gAEnamk6n+9nYAJYmztJg5mks9uIvWz1nqzczNt9OcASuO9pjXq5PT4+DLN+cyWT+Pk9zdeWXlXFFNQ5n8Z1qfXAnOJrWtA1RTdDtPiKXAKv4m6r2+RQhWD
O4H1Z9cbBYb2S5VVXVYTdxonhfVADsxTds32uGe21XinDDfy/C+te2g6RPGYeIj6ua9mwUArvdQ0QArOJvtMl8L7XeJwRt7+6Ay86dMAD4i6ppv3YTJ4r3RQPAXnyn
zKcMQev7u2DZd8eAALyhadp9UQjsdg+RAKgtvlO9pwSBBATaX98OjYUR40570pr2qJs4UbwvCgBW8X/VA2Net3oUILjqm4/hBvX3pTWGtD2dTr8ThcBu9xABAGfx/a
zyA0CQGD8Hbb0PQGL8vHEWcKEhkfhxX1/ff9zEieL9uAMwV/zEUsgZmV99wudzMTdHGBcwDNFbP9gJi384U95gPKRq2stRiOvlHnEGwF78oFs9H05QFH8XLP7h27L4
b7Z3dNzP0pdI4wpAbfH9WL+dO3iAwBT/yKz4BOAtXdfvy2azU14yM6o2cQTAKn7Kx4KPQjngRXynqUYFXxj3cRY/aNZ7dIJEgY/MrxWOMISJok978S+3+VTPg4WXi7
Zl4DU+/jUz/0P2bb9yTnEpAc7ih3zAUwaFR/HjUgKs4iulml+dvjWyd6ZpHe5giv8RX5kflxJgL75h+xQWc172+zyLz7sD1Bbfz6Kvjqw3ujfF7+Mz83l3AKv4yR4Y
s1vwheQEcRCfVwdwFt9P1nvc1tk9T93c6nGe+bw6gFX8LofMr9PWbR+gX9HXTOZfLB7vsnrC53XfzdM20Fl82ls9B3jiJj5PJcAqfmfIW70qCEzx+3fB4phkPk8lwF
78KLZ6JQjiKj4PDlBbfD+LvjrXBOaCL4aZz4MD2Iu/lM4vdryc/MVdfJYdwFl8P1kfZKs3Ee/MZ9kBrOJvKG313M72KR36mJmvxm/BZ7c1ZG4bqCjKTiDE/F31pPEd
PkN8w/a9iuu1ndNWTyDxmSsBiqLcAIQMAcDCycZLIbdhb/F4t/JV52LOFqDqrZ4hflqMzGeyBCSTycMSwBYCEuQ690F++c/tMz8ECEzbF0x8phxg48aNq6anpswnbZ
75yVY4se7h2plPEYKEseATUHymAFAU5bdAyCvGoD7d/DcoLFlpXbOE8IUOM/M1sWzfraLaLRZD/z9FUfYDITvGlzTD4Ka/el/0BXACM/MFFp8pB0gmkwckgG3nV9wM
x375zCxwXgT20qZqtsXM3wmLR4u/2CEAB3Vdv4u17+2HnXnMbAMVRXkHCLnj/DVtcKy96tkJXgT20qYCgsaJEROASy6WHvAtSb35fH770NDQZNhBZ6l/lgAoloBLmm
Bw86vu9d/Ov4JDcCCfz98jEgTMAJBKJn9DAP5s6Dq46VUYX9KEEERgFcwA0NnZ2bxAlg0/ls5euwWOr3uEymPaZmJYwx1syoEwTsAMAIZQqWSylwBsBUmCXPvzMHLV
OoQgZBdgCoCurq7rZUkyHp/WMNWwBHLr98Do5XOfze8lo321qb0wjL0TMAVAyQUeJAAvGf+ebLgUhtf3IAQhugBzAJQg+BMBeAIhCFH5UtdMAlB6ePNTCIG4AJiVOZ
VMIgQhM8CqA5SnjRAIDgA6AQJgRgCdICQQWC8BldNGCEKAgCcA0AkQACwHtBngzQFwd0CZAF4BwHJACQSeAUAIKEDAOwAIQUAI4gAAQhAAgrgAgBDUCUGcAEAI6oAg
bgAgBD4hiCMACIEPCOIKAJMQSABvt3d03I1/MsYHoQGbMvcBkkTITjWT2RdwXtQuj7MDMHNsbPwO8ab+B2DR+DljTPlpXV+VzWbHqKkYoCMRAGCiHCw/+yncOPBk8d
MsQu5SM5m3AuhG7VJRAJh3CMw/HfvundA4cQF0QvZmMpld1FQM0JFIAMw7BK2ZR2HZv4aN51G/qWravQF0o3apaADMKwRt/Tvgsgv45+Op0Rugo8h3B40TeWg/dCdI
ZNpwgMdVTat6CEKA2QS4VEQHmJfdwdqhl6D5q17z3johv8hkMp8H0I3apSIDEFk5aDp1GFo+e6EsmpbWNIWaggE7Eh2A0CFoOvUetHw2c+4ztkDX2/qy2eMBdaN2OQ
JQDGUoa4Kmk4ehZWgm8wsEYIumaRo19Sh0hADMBpEqBKb4uVnxZUJu7c9k0hQ0o9oFAjA3nFQgaD55CNbmXiz3XGBVfNP6qOIUj84CQWCKP8yH+AiAM7B1QdB8shfW
DpsPNzFeTGf+zF44Hkkbyix8QdB8ij/x0QHcubFC0P4cjC5bM6d4rvrqIKz5fD9XmY8O4C7+TIwqn1Siyw1wZvVtcOHqVlg4XYAVp1VY/v0gl+KjA/iAQOnq+h1I0h
9rXJKXZPl2VVWz3rud/5a4C/ChQSqVatd1/TEJIAUAi4xLCcA5SZLeJoQ8rWnaWR/dMdEUAahDhs7OzoWyLF+TmJz835GBgX8XOeDzhQDwqRu1USMA1ELJZ0cIAJ+6
URs1AkAtlHx2hADwqRu1USMA1ELJZ0cIAJ+6URs1AkAtlHx2hADwqRu1USMA1ELJZ0cIAJ+6URs1AkAtlHx2hADwqRu1USMA1ELJZ0cIAJ+6URs1AkAtlHx2hADwqR
u1Uf8fzUBH25TjUs8AAAAASUVORK5CYII=" alt="">
            
            <img *ngIf="getHasGroup()" class="right" (click)="nextEasyBox()" src="data:image/png;b
ase64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAJxklEQVR4Xu2dbWwcRxnH/7vn16Z+SUMgTamVFNEAikgd1yXClPr2nEtcREuVGFoKQhUSAgGCEqdUU
KgrVGFEqahIP/ANVVVD5dIXPtTg3q6vuFEErdMioSakQUDUvDmxE6BpY8e3g2Z9d/G9z93tXWZ2nvtkn2Z353n+v/0/M7MvZ4A+WmfA0Dp6Ch4EgOYQEAAEgOYZ0Dx8cgAC
QPMMaB4+OQABoHkGNA+fHIAA0DwDmodPDkAAaJ4BzcMnByAANM+A5uGTAxAAmmdA8/CVdoCRkREzHo+vBdDQ2tp6Ynx8fF5zPcsOX0kAotHo+kQi8YCbSOwwTbMjGfVFuG6
Mmeao4zh/KjsTmm6gHAAD4fA2ZhjPALiyoGaG8aBt2z8BwDTVVThspQCIRCLb3UTiedM0m3mEM9fdgpMfiiDR2IKrjk3j2r89BzOx4AVvAA/HHOdHBEFxFpQBIEN8w8ChT9
2LYx/5zKXoGNB25jC6x+9D4/z/CAJBD1ACgGzxD968C8c3DGaIn/qnbfYIul8cJgiCAkC2+G/ePIwTG7bnFd/7kjsBh2CcIBBhQGoHqET8DCcgCEoyIC0AOeJ/ejdOXL+t
6JmfHW3bmSPo/gM5QTEKpATAD/FTE0CvHBAEhWfMJT2izg1yxL/lPpz4cLSsMz979k8QFBZRKgcIh8ObTMPYD6AVhoE3fRA/Y2D4RyoH2SjIBIAxYFn7GfAJ3klP/D
Jrft51v2VrgZ4TEAQZDEgDwEB//xZmmvzsx783fQFHbvpaVbafOvNzBoapMcECLRYlV0zrXOQLHM6yrAcNYMQNNWHqS2NYbEou9Wev5udb3S/zu7a55MCQIJDn6eBw
OPykaRh3n/vARkzf9tgSJjUQP2OdgJcDzSGQpgRELGsMwM7ZD/bijcHRmoqfniJyJ9AcAmkAGOjv/xUzzW9dWLEa++7cCz4LSH/KtPiMKlPCRbxyoDEE0gAQiUTuBm
NPcvH+Gn0YZ7q25C8D+UqD6HcFQPIgmNCzHEgDQF9fX1tTQ8PbZijUzl3gtdsfx3zrqtwhY6VuUGI7XSGQBgCutGVZwwbwc/73+c4uHLj1USy0rqy+FAhC460TvKSX
E0gFwNDQUOjs7OxeBgzlQCAoYrUzB88JNIJAKgC46D09PY2dnZ17wdiONASDWU5QZc3PqStZcOkEgXQA5IWgI6sciLiBSJsiIHkQxIJfDqQEoCgELcvGBKlTuUYLRj
pAIC0ABSHILgc1Ej+1EulBYAfXCaQGoCQENRY/vWwcYAikB6AgBNt9miIKXnMIqhMoAUBJCKoc8BVdOl4GSNvZ4JUDZQAoCMG2CqeIgmd+zu1lAYNAKQCEIKjUDcrY
znMCJxgDQ+UAKAqByBSxwjM/NStIDwwDAoGSAAhDIHJWi7QpsGDkDQwn1XYCZQEoCYGIsCJtSiw7e+VAYQiUBqAgBNFHsZBdDmq4ZuA5QVxNJ1AeACEIaih++vYy7g
QKQhAIAIpC0Jx17cAH20+vG2RfRVQQgsAAkBeC9i4cWF4Oaih++toBh+BldcpBoAAoCkG2E5QY3BVdHSx1e5lCEAQOgIIQbM0aGFbqBoLbebODXCd4IAMsCf4JJAAl
IRAUserby85lQsCAbzuOs0cC3dNdCCwABSEYEJgi+rRayHfDnWDzy7vQcPEd/u9FwzQ3xWKxg7JAEGgAhCAQcQORNkWgWTnzOjZP7QYY4w+8/M627Z0EQB0zkHOjKZ
8dcCcQGRhWKX4qzI9OP4K1/xyHm0i4zDCuicfjJ+uYgoKHCrwDpCLPC0GkxMDQJ/F5H1b89yi2TNyTmi3e4zjObwiAOmegKAR+rRYWgaZv/ItoefcUj/ox23G+W+fw
8x5OGwdY7gQrOzqeYcBt/Lvz7V14PfxI5mNoPp75y2cS3VO7cdXMAbiMPT05OXknAXAZMjA0NNQ0Nzf3LBjz3jP7Tud6D4CF5s6l3tRIfL7rFAAAfms7zl2XIfycQ2
rlAJ74s7NPA/hcvcXnx+t78S60vDcDw3V/GYvH7yUA6piByy3+iv/8C1tiX/UiNhj7Smxy8ok6hq/3LOByi8/Lysde+xmuPjrhTQMbm5uvnpiYmCEA6pABGcRfdepV
3LDv/qWzHxiLOc7n6xC60CECPQaQQfy2s4exeWoXGhbfheu682Yo9HHbtg8LqVOHRoEFQArxz72Fza/sRkPyTWQwjK/btv3rOugqfIhAAiCj+AbwUMxxRoSVqVPDwA
FA4pdHTqAAIPHLEz85KC1/Ixm3IPErUyUQDkDiVyZ+IByAxK9cfOUBIPGrE19pAEj86sVXFgAS3x/xlQSAxPdPfOUAIPH9FV8pAEh8/8VXBgASvzbiKwEAiV878aUH
gMSvrfhSA0Di1158aQEg8esjvpQAkPj1E186APhPxsydPj0G07yDd66eD214aWdAW9ZtXLLeyeMXJlJdDrYs6/sGMMqDO9+xDgesX9TliR1dxZfKAQYHB9sX5uePAb
jywoo1eHXrnkvv+qvh41o6iy8VAJZlfdkAvKdl3ugfxeya3iWXI/H9cvu8+5GmBETC4T0wjG9euOL92PfZp5Z+OpbEr6n4UjlA+sej1/R6DkDi11x77wDSOED65+NX
b8S0lfz5+OU5EHEDkTaajvYL4SQNAJFI5Mdg7CHXbMTU7WNYbGq71GcRYUXakPg5HMgEQC8Y+wvv4dENO/HWDd8QHwSS+BXXC2kA4OUoYlmvAPgkj+bgTcM4vm4wN7
Aq3uWj2yKPCBUyAYBof//Gi4z92QyFruCzgIM37sLx9csgIPFFNC2rjVQA8J5HIpGtYOz3AFo8J+gdXoKAxC9LWNHG0gHAO25ZVtQAXkhDcGMSglRUVPNF9S3ZTkoA
8kPAy8GtZa0PUM0vqb886wD5uprjBD1JCATWB0j80uJLtRBUqLvZEBzq+R6Orfde8VfQDUh8MfGVACBfOfAgWJeEIMsNSHxx8ZUBIB8Ef+/+Dt6+znvba9oN2s8eQv
e++9Pv5An6zRzlSZ2/tbSDQJExwem1fTh5bQSJUAtWzUzjmn+8AJMtepuS+GJ4KAUAD2lrOBxZdN1nzVCovUCIDIz90J6c/KlYCvRupRwAXK6BgYEulkj8AIaxA8D7
khK+ZwAvMcMYtW17v96yikevJADLwjOi0ejqxcXFRtd1T8Xj8SX/p49wBlQHQDhQahiAQSCJ6H8GyAH8z6lSeyQAlJLL/84SAP7nVKk9EgBKyeV/ZwkA/3Oq1B4JAK
Xk8r+zBID/OVVqjwSAUnL531kCwP+cKrVHAkApufzvLAHgf06V2iMBoJRc/neWAPA/p0rtkQBQSi7/O0sA+J9Tpfb4f6Jxdurs7TG5AAAAAElFTkSuQmCC" alt="">
            <!--<button (click)="previousEasyBox()">Previous</button>
            <button (click)="nextEasyBox()">Next</button>-->
        </div>
    `,
    styles: [`
        #easyBoxLoading{
            text-align: center;
            z-index: 10001;
            width: 100%;
            height: 100%;
            color: white;
            position: fixed;
            top: 46%;
            font-size: 20px;
        }
        #easyBoxWrapper {
            background-color: rgba(0, 0, 0, 0.9);
            position: fixed;
            top: 0px;
            left: 0px;
            text-align: center;
            z-index: 10000;
            width: 100%;
            height: 100%;
        }

        #easyBoxWrapper #easyBoxContent img {
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            border-radius: 4px;
        }

        #easyBoxContent {
            display: block;
        }

        button {
            font-size: 12px;
        }

        iframe {
            max-width: 100%;
            max-height: 100%;
        }
        #buttons{
            position: relative;
            margin: 5px auto;
            text-align: right;
        }
        #buttons p{
            float: left;
            color: white;
            text-align: left;
            margin-right: 50px;
            font-size: 12px;
        }
        #buttons span.title{
            display: block;
            height: 18px;
            overflow: hidden;
        }
        #closeButton{
            position: absolute;
            top: 0px;
            right: 0px;
            cursor: pointer;
        }
        .left{
            position: absolute;
            left: 0px;
            top: 50%;
            margin-top: -78px;
            cursor: pointer;
        }
        .right{
            position: absolute;
            right: 0px;
            top: 50%;
            margin-top: -78px;
            cursor: pointer;
        }
    `]
})
export class EasyBoxComponent implements DoCheck {

    offsetHeight: number;
    interval: any;
    @Input() data: any;
    @Output() showMore = new EventEmitter();
    @ViewChild('easyBoxContent') elementView: ElementRef;
    @ViewChild('easyBoxButtons') elementButtons: ElementRef;

    constructor(
        public easyBox: EasyBoxService
    ) {
    }

    ngDoCheck() {
        if (this.easyBox.open === true && this.elementView === undefined) {
            this.checkInterval();
        }
    }

    closeOutside($event) {
        if ($event.target.getAttribute('id') === 'easyBoxContent' || $event.target.getAttribute('id') === 'easyBoxWrapper') {
            this.closeEasyBox();
        }
    }

    checkInterval() {
        let t = setInterval(() => {

            if (this.elementView && this.elementButtons  ) {
                this.resize();
                // Stop Loading on frames
                if (this.easyBox.current.type === 2 || this.easyBox.current.type === 3 || this.easyBox.current.type === 4) {
                    this.easyBox.loading = false;
                }

                clearInterval(t);
            }
        }, 10);
    }

    closeEasyBox() {
        this.easyBox.open = false;
    }

    elementExist() {
        if (this.elementView !== undefined) {
            return true;
        }
        return false;
    }

    @HostListener('window:resize', ['$event'])
    resize() {
        // Resize big images

        if ( this.elementView && this.elementButtons) {
            let currentWidth = this.calcPercent(this.easyBox.current.width, window.innerWidth);
            let currentHeight = this.calcPercent(this.easyBox.current.height, window.innerHeight);

            let realWidth   = this.elementView.nativeElement.naturalWidth ?
                              this.elementView.nativeElement.naturalWidth : currentWidth;
            let realHeight  = this.elementView.nativeElement.naturalHeight ?
                              this.elementView.nativeElement.naturalHeight : currentHeight;


            let maxWidth    = Math.min((window.innerWidth - 60), currentWidth ? currentWidth : realWidth);
            let maxHeight   = Math.min((window.innerHeight - 60), currentHeight ? currentHeight : realHeight);

            let ratio       = Math.min( maxWidth / realWidth, maxHeight / realHeight);

            this.elementView.nativeElement.width    = realWidth * ratio;
            this.elementView.nativeElement.height   = realHeight * ratio;


            this.elementButtons.nativeElement.style.width = this.elementView.nativeElement.offsetWidth + 'px';

            // Calculate top padding
            this.offsetHeight = (window.innerHeight - 40 - this.elementView.nativeElement.offsetHeight) / 2;
            if (this.offsetHeight < 0) {
                this.offsetHeight = 0;
            }
        }
    }




    @HostListener('window:keydown', ['$event'])
    checkKeyPress(event: KeyboardEvent) {
        if ( event.keyCode === 39 ) {
            this.nextEasyBox();
        }else if ( event.keyCode === 37 ) {
            this.previousEasyBox();
        }else if ( event.keyCode === 27 ) {
            this.closeEasyBox();
        }
    }

    calcPercent(value, of) {
        if (value !== undefined && value.toString().search('%') >= 0) {
            return of * parseInt(value.toString(), 0) / 100;
        }
        return value;
    }

    getHasGroup() {
        return this.easyBox.current.group !== undefined;
    }

    getCount() {
        return this.easyBox.images.filter(image => image.group === this.easyBox.current.group).length;
    }

    getCurrentIndex() {
        let currentGroup = this.easyBox.images.filter(image => image.group === this.easyBox.current.group);
        return currentGroup.map(function (e) {
            return e.id;
        }).indexOf(this.easyBox.current.id) + 1;
    }

    nextEasyBox() {
        if ( this.easyBox.current.group === undefined ) {
            return false;
        }
        this.easyBox.loading = true;
        let currentGroup = this.easyBox.images.filter(image => image.group === this.easyBox.current.group);
        let pos = currentGroup.map(function (e) {
            return e.id;
        }).indexOf(this.easyBox.current.id);
        if (pos >= currentGroup.length - 1) {
            this.easyBox.current = currentGroup[0];
        } else {
            this.easyBox.current = currentGroup[pos + 1];
        }
        this.checkInterval();
    }

    previousEasyBox() {
        if ( this.easyBox.current.group === undefined ) {
            return false;
        }
        this.easyBox.loading = true;
        let currentGroup = this.easyBox.images.filter(image => image.group === this.easyBox.current.group);
        let pos = currentGroup.map(function (e) {
            return e.id;
        }).indexOf(this.easyBox.current.id);
        if (pos === 0) {
            pos = currentGroup.length;
        }
        this.easyBox.current = currentGroup[pos - 1];
        this.checkInterval();
    }

    isLoaded() {
        if (this.easyBox.current.type === 1) {
            this.easyBox.loading = false;
        }

        this.checkInterval();
    }

}
